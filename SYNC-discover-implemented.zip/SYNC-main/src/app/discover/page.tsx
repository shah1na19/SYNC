"use client";

import { useMemo, useState } from "react";
import { Compass, Sparkles } from "lucide-react";
import { BuddyCard } from "@/ui/discover/BuddyCard";
import {
  BuddyFilters,
  DEFAULT_BUDDY_FILTERS,
  type BuddyFilterState,
} from "@/ui/discover/BuddyFilters";
import { CURRENT_STUDENT, STUDENTS } from "@/data/students";
import { COURSES } from "@/data/courses";
import { calculateMatch } from "@/core/matching";

function availabilityMatches(availability: string[], selected: string[]) {
  if (selected.length === 0) return true;

  return selected.some((filter) =>
    availability.some((slot) => {
      const normalized = slot.toLowerCase();
      if (filter === "Morning") return normalized.includes("morning");
      if (filter === "Afternoon") return normalized.includes("afternoon");
      if (filter === "Evening") return normalized.includes("evening") || normalized.includes("night");
      if (filter === "Weekends") return normalized.startsWith("sat") || normalized.startsWith("sun");
      return false;
    }),
  );
}

export default function DiscoverPage() {
  const [filters, setFilters] = useState<BuddyFilterState>(DEFAULT_BUDDY_FILTERS);

  const courseMap = useMemo(
    () => new Map(COURSES.map((course) => [course.id, `${course.code} · ${course.name}`])),
    [],
  );

  const courseOptions = useMemo(
    () =>
      COURSES.map((course) => ({
        id: course.id,
        label: course.name,
      })),
    [],
  );

  const matches = useMemo(() => {
    return STUDENTS.map((student) => calculateMatch(CURRENT_STUDENT, student))
      .filter((match) => {
        const { student } = match;

        const courseMatch =
          filters.courses.length === 0 ||
          filters.courses.some((courseId) => student.courses.includes(courseId));

        const yearMatch =
          filters.years.length === 0 || filters.years.includes(student.year);

        const availabilityMatch = availabilityMatches(
          student.availability,
          filters.availability,
        );

        const styleMatch =
          filters.studyStyles.length === 0 ||
          filters.studyStyles.includes(student.studyStyle);

        return (
          courseMatch &&
          yearMatch &&
          availabilityMatch &&
          styleMatch &&
          match.compatibilityScore >= filters.minimumMatch
        );
      })
      .sort((a, b) => b.compatibilityScore - a.compatibilityScore);
  }, [filters]);

  return (
    <div className="space-y-5">
      <div className="relative overflow-hidden rounded-[var(--radius-lg)] border border-primary/15 bg-gradient-to-br from-primary/[0.09] via-elevated to-elevated p-5 shadow-[var(--shadow-elevated)]">
        <div
          aria-hidden
          className="absolute -top-20 right-[-4rem] h-48 w-48 rounded-full bg-primary/10 blur-3xl"
        />
        <div className="relative flex items-start justify-between gap-5">
          <div className="min-w-0">
            <div className="mb-2 flex items-center gap-2 text-label text-primary">
              <Compass size={13} aria-hidden />
              STUDY BUDDY DISCOVERY
            </div>
            <h1 className="text-2xl font-semibold tracking-[-0.035em] text-foreground">
              Find the people who study the way you do.
            </h1>
            <p className="mt-1.5 max-w-2xl text-secondary">
              Explore compatible HITSZ students based on your courses, schedule, and study style.
            </p>
          </div>
          <div className="hidden shrink-0 items-center gap-2 rounded-full border border-border bg-background/40 px-3 py-1.5 text-[11px] text-muted-foreground md:flex">
            <Sparkles size={12} className="text-primary" aria-hidden />
            Compatibility-first
          </div>
        </div>
      </div>

      <BuddyFilters
        filters={filters}
        courseOptions={courseOptions}
        resultCount={matches.length}
        onChange={setFilters}
        onReset={() => setFilters(DEFAULT_BUDDY_FILTERS)}
      />

      <section aria-labelledby="buddy-results-title">
        <div className="mb-3 flex items-end justify-between gap-3">
          <div>
            <h2 id="buddy-results-title" className="text-section-title">
              Recommended study buddies
            </h2>
            <p className="mt-0.5 text-meta">
              Ranked by compatibility with your current academic profile.
            </p>
          </div>
          <p className="text-meta">{matches.length} matches</p>
        </div>

        {matches.length > 0 ? (
          <div className="grid grid-cols-1 gap-3 xl:grid-cols-2">
            {matches.map((match) => (
              <BuddyCard
                key={match.student.id}
                buddy={match.student}
                score={match.compatibilityScore}
                matchingReasons={match.matchingReasons}
                courseLabels={match.student.courses.map(
                  (id) => courseMap.get(id) ?? id,
                )}
                onConnect={() => {
                  window.location.href = `/match?student=${encodeURIComponent(match.student.id)}`;
                }}
              />
            ))}
          </div>
        ) : (
          <div className="surface-card flex min-h-48 flex-col items-center justify-center p-8 text-center">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Compass size={18} aria-hidden />
            </div>
            <h3 className="mt-3 text-card-title">No close matches yet</h3>
            <p className="mt-1 max-w-md text-secondary">
              Try relaxing one of your filters to discover more students.
            </p>
            <button
              type="button"
              onClick={() => setFilters(DEFAULT_BUDDY_FILTERS)}
              className="interactive mt-4 rounded-[var(--radius-md)] border border-border bg-background/50 px-3 py-2 text-[12px] font-medium text-foreground hover:bg-white/[0.035]"
            >
              Reset filters
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
